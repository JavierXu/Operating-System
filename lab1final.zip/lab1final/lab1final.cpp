//
//  lab1final.cpp
//  lab 1
//
//  Created by Yaozhong Xu on 2019/9/15.
//  Copyright © 2019 Yaozhong Xu. All rights reserved.
//
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <string.h>
#include <map>
#include <algorithm>


using namespace std;

int main(int argc, const char * argv[])
{
    map<int, int> AddressTab;//Memory map
    vector<vector<string>> module;//Module lines
    vector<int>BA; //Base address of each module
    int BaseAddress = 0;//initial base address
    BA.push_back(BaseAddress); //add initial base address
    int NumModule;//# of module
    int m ;
    scanf("%d", &NumModule);//input number of module
    map<string, int> DefList; //Variables defined and values
    vector<string> UsedVar;//Variables used
    map<string, int> UseList;//Variables used and its relative address in the module
    vector<int> code;//program list
    int LegalSize = 200;//largest legal size is 200
    
    for (m=0; m<NumModule;m++)//process input to record all modules
    {
        int NumDef;//number of defined variables
        int NumUse;//number of used variables
        char DefVar[1023];//defined variable name
        int DefVal;//relative address of defined variable
        char UseVar[1023];//used variable name
        int UseVal;//relative address of used variable
        int NumAdd;//number of code/program
        int Add;//the program
        
        vector<string> program;//record the third line of each module
        vector<string> definition;//record the first line of each module
        vector<string> use;//record the second line of each module
        map<string, int> VARUSE;//the actual variable used
        
        scanf("%d", &NumDef);
        definition.push_back(to_string(NumDef));
        int i;
        if (NumDef!=0)
        {
            for (i = 1; i<NumDef+1; i++)//record the definition line
            {
                scanf("%s %d", DefVar, &DefVal);
                definition.push_back(DefVar);
                definition.push_back(to_string(DefVal));
            }
        }
        module.push_back(definition);//record the whole definitionn list of each module
        
        
        scanf("%d", &NumUse);
        int pholder = NumUse;
        int a;
        for (a = 1; a<pholder+1; a++)
        {
            scanf("%s %d", UseVar, &UseVal);
            for (auto tt = VARUSE.begin();tt!= VARUSE.end();++tt)
            {
                if (tt->second == UseVal)//handle error #4
                {
                    string w = tt->first;
                    VARUSE.erase(w);//delete existing usage
                    cout<<"multiple symbols: "<< tt->first<<" ,"<<UseVar<<" are listed as used in the same instruction. The value of "<<UseVar<<" is used.";
                    NumUse--;
                    break;
                }
            }
            VARUSE.insert(pair<string, int>(UseVar,UseVal));//insert new usage
        }
        use.push_back(to_string(NumUse));//insert the actual number of variable used
        for (auto it = VARUSE.begin();it!=VARUSE.end();++it)//record the use line
        {
            use.push_back(it->first);
            use.push_back(to_string(it->second));
            UsedVar.push_back(it->first);
        }
        module.push_back(use);//record the entire use list
        
        scanf("%d", &NumAdd);
        program.push_back(to_string(NumAdd));//record the number of programs
        int n;
        for (n=0; n<NumAdd; n++)
        {
            scanf("%d", &Add);
            program.push_back(to_string(Add));//record program
        }
        module.push_back(program);//record the entire program list
    }
    
    //first pass
    int i=0;
    for (auto it = module.begin(); it != module.end(); ++it)
    {
        if ((i+1)%3==1)//definition list
        {
            vector<string> line = *it;
            vector<string> cline = *(it+2);
            int NumVar = stoi(*line.begin());//number of defined variables
            int n = 1;
            while (NumVar != 0 && n<NumVar+1)
            {
                int pos = 2*n;//the position of the address of the defined variable
                string var = *(line.begin()+pos-1);//the name of defined variable
                if (DefList.count(var)==0)
                {
                    int value = stoi(*(line.begin()+pos));
                    if (value >= stoi(*cline.begin()))
                    {
                        value = 0;// handle error #5
                        cout << "Error: The definition of "<<var<<" is outside module "<<(i+1)/3<<". 0 (relative) is given instead\n ";
                    }
                    value += BaseAddress;//record the actual address of the defined variables
                    if (value>LegalSize-1)
                    {
                        value = LegalSize-1;
                        cout<<"The absolute address of "<<var<<" exceeds the size of the machine; largest legal value used instead\n";//error #8
                    }
                    DefList.insert(pair<string, int>(var, value));//insert the variable and address pair
                    n++;
                }
                else if (DefList.count(var)!=0)//handle error #2
                {
                    cout << "Error: Variable "<<var<< " is multiply defined. The first value is used.\n";
                    break;
                }
                
            }
        }
        
        else if ((i+1)%3 == 0 && ((i+1)!=module.size()))//record base address of each module
        {
            vector<string> line = *it;
            int NumProgram = stoi(*line.begin());
            BaseAddress += NumProgram;
            BA.push_back(BaseAddress);
        }
        i++;
    }
    
    //second pass
    int a =0;
    int nba = *BA.begin();//base address
    int tba = *BA.begin();//base address
    for (auto it = module.begin(); it != module.end(); ++it)
    {
        if ((a+1)%3 ==2)//use list
        {
            vector<string> spiece = *it;
            vector<string> tpiece = *(it+1);
            int NumVarUse = stoi(*spiece.begin());//number of variables used
            int VarPos;
            
            for (VarPos = 1; VarPos < NumVarUse+1; VarPos++)
            {
                int pos = stoi(*(spiece.begin()+2*VarPos));//relative address of the used variables
                int MapPos = 2*VarPos-1;//position of the used variable
                int val;//actual address of the used variable
                map<string, int>::iterator ita;
                ita = DefList.find(*(spiece.begin()+MapPos));//is the used variable defined?
                int end = stoi(*(tpiece.begin()+pos+1));//the program
                code.push_back(end);
                int lastdigit = end - (end/10)*10;//the last digit of the program
                int exit = end/10 - (end/10)/1000*1000;//the relative address for redirection
                int place = pos;//placeholder
                //                if (ita == DefList.end())
                //              {
                //                val = 0;
                //             cout << "Error: At base adress "<<nba+pos<<", "<< *(spiece.begin()+MapPos)<<" is used but not defined, and it has been given the value 0\n";
                //             }
                //           else
                //             {
                //                  val = ita->second;
                //            }
                while (lastdigit == 1)
                {
                    if (ita == DefList.end())
                    {
                        val = 0;
                        pos = exit;
                        cout << "Error: At address "<<nba+pos<<", "<< *(spiece.begin()+MapPos)<<" is used but not defined, and it has been given the value 0\n";//handle error#3
                    }
                    else
                    {
                        val = ita->second;
                    }
              //      cout<<"Error: At address "<<nba+pos<<", Immediate address on use list; treated as External.\n";//error #6
                    int StAbsAdd = (end/10000)*1000 + val;//real address
                    cout<<"Error: "<<nba+pos<<": "<<StAbsAdd<<", Immediate address on use list; treated as External.\n"; //Error #6
                    AddressTab.insert(pair<int, int>(nba+pos,StAbsAdd));
                    end = stoi(*(tpiece.begin()+exit+1));//redirected program
                    code.push_back(end);
                    place = exit;//placeholder
                    lastdigit = end - (end/10)*10;
                    exit = end/10 - (end/10)/1000*1000;
                    pos = place;
                    
                }
                while (exit != 777 && lastdigit ==4)//get program address
                {
                    
                    if (ita == DefList.end())
                    {
                        val = 0;
                        cout << "Error: At address "<<nba+pos<<", "<< *(spiece.begin()+MapPos)<<" is used but not defined, and it has been given the value 0\n";//#error number 3
                    }
                    else
                    {
                        val = ita->second;
                    }
                    int AbsAdd = (end/10000)*1000 + val;
                    AddressTab.insert(pair<int, int> (nba+pos,AbsAdd));
                    end = stoi(*(tpiece.begin()+exit+1));
                    code.push_back(end);
                    place = exit;
                    lastdigit = end - (end/10)*10;
                    exit = end/10 -(end/10)/1000*1000;
                    pos = place;
                    if(lastdigit==1)
                    {
                        lastdigit=4;
                        cout<<"Error: "<<nba+pos<<": "<<AbsAdd<<", Immediate address on use list; treated as External.\n"; //Error #6
                    }
                }
                //loop ended at 777
                if (ita == DefList.end())
                {
                    val = 0;
                    cout << "Error: At address "<<nba+pos<<", "<< *(spiece.begin()+MapPos)<<" is used but not defined, and it has been given the value 0\n";//error #3
                }
                else
                {
                    val = ita->second;
                }
                int AbsAdd = (end/10000)*1000 + val;
                //              cout << "Error: At base adress "<<nba+place<<", "<< *(spiece.begin()+MapPos)<<" is used but not defined, and it has been given the value 0\n";
                AddressTab.insert(pair<int, int> (nba+place,AbsAdd));
            }
            nba =*(BA.begin()+a/3+1);
            //      cout << "nba is "<<nba<<"\n";
        }
        
        else if ((a+1)%3 == 0)//change program addresses
        {
            int npos;
            vector<string> tpiece = *it;
            int NumProgram = stoi(*tpiece.begin());//number of programs
            for (npos = 0; npos < NumProgram; npos++)
            {
                int program = stoi(*(tpiece.begin()+npos+1));// the program
                if ((program-(program/10)*10)==1)//immediate operand
                {
                    program = program/10;
                    AddressTab.insert(pair<int, int>(tba+npos,program));
                }
                else if ((program-(program/10)*10)==2)//absolute address
                {
                    int holder = program;
                    program = program/10;
                    if (program > program/1000*1000+LegalSize-1)
                    {
                        program = program/1000*1000+LegalSize-1;
                        cout<<"Error: The absolute address of "<< holder<<" exceeds the size of the machine; largest legal value used instead\n";//error #8
                    }
                    AddressTab.insert(pair<int, int>(tba+npos,program));
                }
                else if ((program-(program/10)*10)==3)//relative address
                {
                    int holder=program;
                    program = program/10+tba;
                    if (program > program/1000*1000+LegalSize-1)
                    {
                        cout<<"Error: The absolute address of "<<tba+npos<<": " << holder<<" exceeds the size of the machine; largest legal value used instead\n";//error #8
                        program = program/1000*1000+LegalSize-1;
                    }
                    AddressTab.insert(pair<int, int>(tba+npos,program));
                }
                else if((program-(program/10)*10)==4 && (find(code.begin(), code.end(), program)==code.end()))
                {
                    int holder = program;
                    program = program/10;
                    AddressTab.insert(pair<int, int>(tba+npos,program));
                    cout<<"Error: At "<<tba+npos<<": "<< program<<", the external address "<<holder<<" is not on use list. Treated as an immediate address\n";//error #7
                }
            }
            tba =*(BA.begin()+(a+1)/3);
        }
        a++;
    }
    
    sort(UsedVar.begin(), UsedVar.end() );//sort the list of the used variable
    UsedVar.erase( unique( UsedVar.begin(), UsedVar.end() ), UsedVar.end() );//erase duplicate used variable from the list
    
    cout<<"Symbol Table\n";
    for (auto ot = DefList.begin(); ot != DefList.end(); ++ot)
    {
        cout<<ot->first<<"="<<ot->second <<"\n";
    }
    cout<<"Memory Map\n";
    for (auto ot = AddressTab.begin(); ot != AddressTab.end(); ++ot)
    {
        cout << ot->first
        << ":  " << ot->second << '\n';
    }
    for (auto itr = DefList.begin(); itr != DefList.end(); ++itr)
    {
        string VarName = itr->first;
        if ((find(UsedVar.begin(), UsedVar.end(), VarName) == UsedVar.end()))
        {
            cout << "Warning: Variable " << VarName << " is defined but never used\n";//error #1
        }
    }
    return 0;
}
